export enum ApiRoutes {
  SEARCH_PRODUCTS = 'products/search',
  INGREDIENTS = 'ingredients',
}
